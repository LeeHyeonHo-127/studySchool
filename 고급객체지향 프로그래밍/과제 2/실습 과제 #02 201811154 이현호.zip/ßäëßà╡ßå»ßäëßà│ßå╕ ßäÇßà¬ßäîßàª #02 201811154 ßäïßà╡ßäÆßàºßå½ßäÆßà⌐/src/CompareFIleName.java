import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Sorter{

    public Comparable comparable;

    public void setComparable(Comparable comparable){

    }

    public void Sorter(Comparable comparable){

    }
    public void bubbleSort(Object[] data){

    }
}
