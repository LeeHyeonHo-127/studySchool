import java.util.ArrayList;

public class LoadHudDisplays implements LoadDisplayInterface{

    LoadHudDisplays(String filename){

    }
    @Override
    public ArrayList<String> load() {
        return null;
    }
}
