public interface ShapeFactoryInterface {
    public Shape createShape(String type, String name, int min, int max);
}
