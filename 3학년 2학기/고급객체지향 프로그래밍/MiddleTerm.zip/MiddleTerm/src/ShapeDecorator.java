public interface ShapeDecorator extends Shape{

    public void calcBounds();

    public abstract String getShapeName();

    public String toString();



}
