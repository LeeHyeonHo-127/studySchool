class Printer {
    static void print(Object[] data) {
        for (Object i : data) {
            System.out.println(i);
        }
    }
}